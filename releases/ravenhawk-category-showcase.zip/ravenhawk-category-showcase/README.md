# RavenHawk Category Showcase

A lightweight WordPress plugin that turns the default article category list into a styled RavenHawkTech category showcase.

## Version

`2.1.0`

## Purpose

This plugin is designed for the top of the RavenHawkTech blog/articles page. Instead of showing a plain list of category hyperlinks, it displays responsive neon category cards with category names, descriptions, article counts, and links.

## Installation

1. Go to **WordPress Admin → Plugins → Add Plugin**.
2. Click **Upload Plugin**.
3. Upload `ravenhawk-category-showcase-2.1.0.zip`.
4. Click **Install Now**.
5. Activate the plugin.

## Automatic Blog Page Display

By default, the plugin attempts to add the showcase to the top of the assigned WordPress Posts page.

To change this, go to **Settings → RavenHawk Categories** and toggle **Auto-add to blog page**.

## Shortcode

```text
[ravenhawk_category_showcase]
```

Example with options:

```text
[ravenhawk_category_showcase limit="8" show_counts="true" show_descriptions="true"]
```

## Shortcode Options

| Option | Default | Description |
|---|---:|---|
| `limit` | `12` | Maximum number of categories to show |
| `include_empty` | `false` | Show categories with zero posts |
| `show_counts` | `true` | Show article counts |
| `show_descriptions` | `true` | Show category descriptions |
| `exclude` | empty | Comma-separated category IDs to exclude |
| `include` | empty | Comma-separated category IDs to include |

## Recommended Use

```text
[ravenhawk_category_showcase limit="8"]
```

## Security Notes

- No external API calls.
- No tracking.
- No database tables.
- No user-submitted frontend forms.
- Admin settings require `manage_options`.

## License

GPL-3.0-or-later.


## 2.1.0 GitHub Updater

This version adds custom GitHub-based update support.

- Adds `Update URI` to avoid WordPress.org plugin conflicts.
- Uses the repository update manifest: `updates/ravenhawk-category-showcase.json`
- Uses GitHub Release assets for update ZIP downloads.
- Supports SHA-256 checksum verification before installing an update.


## Editable colors

Version 2.1.0 adds admin color controls under **RavenHawkTech → Category Showcase**. Site admins can adjust the accent colors, background colors, card colors, text colors, and border radius without editing the plugin CSS file.
