<?php
/**
 * Plugin Name: RavenHawk Category Showcase
 * Plugin URI: https://ravenhawktech.com
 * Description: Displays a styled WordPress category showcase with shortcode support and optional blog-page insertion. Visit https://ravenhawktech.com for RavenHawkTech.
 * Version: 2.1.0
 * Author: RavenHawkTech
 * Requires at least: 6.2
 * Requires PHP: 8.0
 * Update URI: https://github.com/RavenHawkTech/RHT_Wordpress
 * License: GPL-3.0-or-later
 */

if (!defined('ABSPATH')) { exit; }

define('RHCS_VERSION', '2.1.0');
define('RHCS_PLUGIN_FILE', __FILE__);
define('RHCS_PLUGIN_URL', plugin_dir_url(__FILE__));

class RHCS_Category_Showcase {
    public static function init(): void {
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_shortcode('ravenhawk_category_showcase', [__CLASS__, 'shortcode']);
        add_filter('the_content', [__CLASS__, 'maybe_prepend_to_blog_page'], 8);
    }

    public static function enqueue_assets(): void {
        wp_register_style('ravenhawk-category-showcase', RHCS_PLUGIN_URL . 'assets/ravenhawk-category-showcase.css', [], RHCS_VERSION);
        wp_add_inline_style('ravenhawk-category-showcase', self::custom_css_variables());
    }

    private static function default_style_options(): array {
        return [
            'accent' => '#22c55e',
            'accent_soft' => '#86efac',
            'background_start' => '#020617',
            'background_end' => '#0f172a',
            'card_start' => '#0f172a',
            'card_end' => '#020617',
            'text' => '#f8fafc',
            'muted_text' => '#cbd5e1',
            'meta_text' => '#94a3b8',
            'border_radius' => '24',
            'card_radius' => '18',
        ];
    }

    public static function style_options(): array {
        $defaults = self::default_style_options();
        $saved = get_option('rhcs_style_options', []);
        if (!is_array($saved)) {
            $saved = [];
        }

        return array_merge($defaults, array_intersect_key($saved, $defaults));
    }

    private static function sanitize_hex_color_value(string $value, string $fallback): string {
        $value = sanitize_hex_color($value);
        return $value ?: $fallback;
    }

    private static function custom_css_variables(): string {
        $options = self::style_options();

        $accent = self::sanitize_hex_color_value((string) $options['accent'], '#22c55e');
        $accent_soft = self::sanitize_hex_color_value((string) $options['accent_soft'], '#86efac');
        $background_start = self::sanitize_hex_color_value((string) $options['background_start'], '#020617');
        $background_end = self::sanitize_hex_color_value((string) $options['background_end'], '#0f172a');
        $card_start = self::sanitize_hex_color_value((string) $options['card_start'], '#0f172a');
        $card_end = self::sanitize_hex_color_value((string) $options['card_end'], '#020617');
        $text = self::sanitize_hex_color_value((string) $options['text'], '#f8fafc');
        $muted_text = self::sanitize_hex_color_value((string) $options['muted_text'], '#cbd5e1');
        $meta_text = self::sanitize_hex_color_value((string) $options['meta_text'], '#94a3b8');
        $border_radius = max(0, min(60, absint($options['border_radius'])));
        $card_radius = max(0, min(60, absint($options['card_radius'])));

        $accent_rgb = self::hex_to_rgb_string($accent);
        $text_rgb = self::hex_to_rgb_string($text);

        return ".rhcs-wrap{--rhcs-accent: {$accent};--rhcs-accent-soft: {$accent_soft};--rhcs-accent-rgb: {$accent_rgb};--rhcs-bg-start: {$background_start};--rhcs-bg-end: {$background_end};--rhcs-card-start: {$card_start};--rhcs-card-end: {$card_end};--rhcs-text: {$text};--rhcs-text-rgb: {$text_rgb};--rhcs-muted: {$muted_text};--rhcs-meta: {$meta_text};--rhcs-radius: {$border_radius}px;--rhcs-card-radius: {$card_radius}px;}";
    }

    private static function hex_to_rgb_string(string $hex): string {
        $hex = ltrim($hex, '#');

        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        if (strlen($hex) !== 6) {
            return '34,197,94';
        }

        return hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2));
    }

    public static function maybe_prepend_to_blog_page(string $content): string {
        if (is_admin() || !is_main_query() || !in_the_loop()) { return $content; }
        if (get_option('rhcs_auto_prepend_blog_page', '1') !== '1') { return $content; }

        $posts_page_id = (int) get_option('page_for_posts');
        if ($posts_page_id > 0 && is_page($posts_page_id)) {
            return self::render_showcase([]) . $content;
        }
        return $content;
    }

    public static function shortcode(array $atts = []): string {
        $atts = shortcode_atts([
            'include_empty' => 'false',
            'limit' => '12',
            'show_counts' => 'true',
            'show_descriptions' => 'true',
            'exclude' => '',
            'include' => '',
        ], $atts, 'ravenhawk_category_showcase');

        return self::render_showcase($atts);
    }

    private static function parse_id_list(string $value): array {
        if (trim($value) === '') { return []; }
        return array_filter(array_map('absint', explode(',', $value)));
    }

    public static function render_showcase(array $atts = []): string {
        wp_enqueue_style('ravenhawk-category-showcase');

        $include_empty = isset($atts['include_empty']) && $atts['include_empty'] === 'true';
        $limit = isset($atts['limit']) ? max(1, min(50, (int) $atts['limit'])) : 12;
        $show_counts = !isset($atts['show_counts']) || $atts['show_counts'] !== 'false';
        $show_descriptions = !isset($atts['show_descriptions']) || $atts['show_descriptions'] !== 'false';
        $exclude = self::parse_id_list($atts['exclude'] ?? '');
        $include = self::parse_id_list($atts['include'] ?? '');

        $args = [
            'taxonomy' => 'category',
            'hide_empty' => !$include_empty,
            'orderby' => 'count',
            'order' => 'DESC',
            'number' => $limit,
            'exclude' => $exclude,
        ];

        if (!empty($include)) {
            $args['include'] = $include;
            $args['orderby'] = 'include';
            unset($args['number']);
        }

        $categories = get_categories($args);
        if (empty($categories) || is_wp_error($categories)) { return ''; }

        $icons = [
            'troubleshooting-recovery' => '🛠️',
            'troubleshooting' => '🛠️',
            'recovery' => '🛠️',
            'virtualization-homelab' => '🧪',
            'virtualization' => '🧪',
            'homelab' => '🧪',
            'infrastructure-systems' => '🖥️',
            'infrastructure' => '🖥️',
            'systems' => '🖥️',
            'automation-devops' => '⚙️',
            'automation' => '⚙️',
            'devops' => '⚙️',
            'security' => '🛡️',
            'cybersecurity' => '🛡️',
            'linux' => '🐧',
            'windows' => '🪟',
            'wordpress' => '📝',
        ];

        ob_start(); ?>
        <section class="rhcs-wrap" aria-label="RavenHawkTech article categories">
            <div class="rhcs-header">
                <p class="rhcs-kicker">Explore RavenHawkTech</p>
                <h2>Browse by Engineering Focus</h2>
                <p class="rhcs-intro">Jump into practical infrastructure guides, troubleshooting notes, automation workflows, and homelab builds.</p>
            </div>

            <div class="rhcs-grid">
                <?php foreach ($categories as $category): ?>
                    <?php
                    $slug = sanitize_html_class($category->slug);
                    $icon = $icons[$category->slug] ?? self::fallback_icon($category->name);
                    $link = get_category_link($category);
                    $description = trim(category_description($category));
                    if ($description === '') { $description = self::fallback_description($category->name); }
                    ?>
                    <a class="rhcs-card rhcs-card-<?php echo esc_attr($slug); ?>" href="<?php echo esc_url($link); ?>">
                        <span class="rhcs-glow"></span>
                        <span class="rhcs-icon" aria-hidden="true"><?php echo esc_html($icon); ?></span>
                        <span class="rhcs-card-body">
                            <span class="rhcs-title"><?php echo esc_html($category->name); ?></span>
                            <?php if ($show_descriptions): ?>
                                <span class="rhcs-desc"><?php echo esc_html(wp_trim_words(wp_strip_all_tags($description), 22)); ?></span>
                            <?php endif; ?>
                            <span class="rhcs-meta">
                                <?php if ($show_counts): ?>
                                    <span><?php echo esc_html(number_format_i18n((int) $category->count)); ?> article<?php echo ((int) $category->count === 1) ? '' : 's'; ?></span>
                                <?php endif; ?>
                                <span class="rhcs-arrow">View category →</span>
                            </span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
        <?php return (string) ob_get_clean();
    }

    private static function fallback_icon(string $name): string {
        $lower = strtolower($name);
        if (str_contains($lower, 'linux')) { return '🐧'; }
        if (str_contains($lower, 'windows')) { return '🪟'; }
        if (str_contains($lower, 'security') || str_contains($lower, 'cyber')) { return '🛡️'; }
        if (str_contains($lower, 'cloud') || str_contains($lower, 'network')) { return '☁️'; }
        if (str_contains($lower, 'automation') || str_contains($lower, 'devops')) { return '⚙️'; }
        return '⌁';
    }

    private static function fallback_description(string $name): string {
        $lower = strtolower($name);
        if (str_contains($lower, 'troubleshoot') || str_contains($lower, 'recovery')) {
            return 'Real-world fixes, outage notes, recovery paths, and lessons learned from infrastructure work.';
        }
        if (str_contains($lower, 'virtual') || str_contains($lower, 'homelab')) {
            return 'VMware, Proxmox, KVM, containers, lab architecture, and self-hosted infrastructure builds.';
        }
        if (str_contains($lower, 'infrastructure') || str_contains($lower, 'systems')) {
            return 'Windows, Linux, identity, storage, DNS, certificates, email, and enterprise systems engineering.';
        }
        if (str_contains($lower, 'automation') || str_contains($lower, 'devops')) {
            return 'Ansible, AWX, scripting, CI/CD, repeatable deployments, and operational automation.';
        }
        return 'Practical RavenHawkTech articles, guides, walkthroughs, and notes from the field.';
    }
}

/**
 * RavenHawk GitHub updater.
 */
class RHCS_GitHub_Updater {
    private const MANIFEST_URL = 'https://raw.githubusercontent.com/RavenHawkTech/RHT_Wordpress/main/updates/ravenhawk-category-showcase.json';

    public static function init(): void {
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'check_for_update']);
        add_filter('plugins_api', [__CLASS__, 'plugin_info'], 20, 3);
        add_filter('upgrader_pre_install', [__CLASS__, 'verify_download_checksum'], 10, 2);
        add_filter('upgrader_post_install', [__CLASS__, 'fix_install_folder'], 10, 3);
    }

    private static function manifest(): array {
        $cached = get_site_transient('rhcs_github_update_manifest');
        if (is_array($cached)) {
            return $cached;
        }

        $response = wp_remote_get(self::MANIFEST_URL, [
            'timeout' => 15,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($response)) {
            return [];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return [];
        }

        $json = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($json)) {
            return [];
        }

        set_site_transient('rhcs_github_update_manifest', $json, 30 * MINUTE_IN_SECONDS);
        return $json;
    }

    public static function check_for_update($transient) {
        if (empty($transient) || !is_object($transient)) {
            return $transient;
        }

        $plugin_file = plugin_basename(RHCS_PLUGIN_FILE);
        $manifest = self::manifest();

        if (empty($manifest['version']) || empty($manifest['download_url'])) {
            return $transient;
        }

        if (version_compare(RHCS_VERSION, (string) $manifest['version'], '<')) {
            $transient->response[$plugin_file] = (object) [
                'id' => $manifest['homepage'] ?? 'https://github.com/RavenHawkTech/RHT_Wordpress',
                'slug' => dirname($plugin_file),
                'plugin' => $plugin_file,
                'new_version' => (string) $manifest['version'],
                'url' => $manifest['homepage'] ?? 'https://github.com/RavenHawkTech/RHT_Wordpress',
                'package' => (string) $manifest['download_url'],
                'tested' => $manifest['tested'] ?? '',
                'requires_php' => $manifest['requires_php'] ?? '8.0',
            ];
        } else {
            unset($transient->response[$plugin_file]);
        }

        return $transient;
    }

    public static function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information') {
            return $result;
        }

        $plugin_file = plugin_basename(RHCS_PLUGIN_FILE);
        if (empty($args->slug) || $args->slug !== dirname($plugin_file)) {
            return $result;
        }

        $manifest = self::manifest();
        if (!$manifest) {
            return $result;
        }

        return (object) [
            'name' => $manifest['name'] ?? 'RavenHawk Category Showcase',
            'slug' => dirname($plugin_file),
            'version' => $manifest['version'] ?? RHCS_VERSION,
            'author' => '<a href="https://RavenHawkTech.com">RavenHawkTech</a>',
            'homepage' => $manifest['homepage'] ?? 'https://github.com/RavenHawkTech/RHT_Wordpress',
            'requires' => $manifest['requires'] ?? '6.2',
            'tested' => $manifest['tested'] ?? '',
            'requires_php' => $manifest['requires_php'] ?? '8.0',
            'sections' => [
                'description' => $manifest['description'] ?? 'Styled category showcase plugin for RavenHawkTech.',
                'changelog' => $manifest['changelog'] ?? '',
            ],
            'download_link' => $manifest['download_url'] ?? '',
        ];
    }

    public static function verify_download_checksum($response, $hook_extra) {
        if (empty($hook_extra['plugin']) || $hook_extra['plugin'] !== plugin_basename(RHCS_PLUGIN_FILE)) {
            return $response;
        }

        $manifest = self::manifest();
        if (empty($manifest['sha256'])) {
            return $response;
        }

        $package = $hook_extra['package'] ?? '';
        if (!$package || !file_exists($package)) {
            return $response;
        }

        $actual = hash_file('sha256', $package);
        $expected = strtolower(trim((string) $manifest['sha256']));

        if (!hash_equals($expected, strtolower($actual))) {
            return new WP_Error(
                'rhcs_checksum_failed',
                'RavenHawk Category Showcase update checksum verification failed. Expected ' . $expected . ' but got ' . $actual . '.'
            );
        }

        return $response;
    }

    public static function fix_install_folder($response, $hook_extra, $result) {
        global $wp_filesystem;

        if (empty($hook_extra['plugin']) || $hook_extra['plugin'] !== plugin_basename(RHCS_PLUGIN_FILE)) {
            return $response;
        }

        $proper_destination = WP_PLUGIN_DIR . '/' . dirname(plugin_basename(RHCS_PLUGIN_FILE));
        if (!empty($result['destination']) && $result['destination'] !== $proper_destination && $wp_filesystem->exists($result['destination'])) {
            $wp_filesystem->move($result['destination'], $proper_destination, true);
            $result['destination'] = $proper_destination;
        }

        return $response;
    }
}

RHCS_GitHub_Updater::init();

RHCS_Category_Showcase::init();

class RHCS_Admin {
    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'settings']);
    }

    public static function menu(): void {
        if (!self::admin_menu_slug_exists('ravenhawktech')) {
            add_menu_page(
                'RavenHawkTech',
                'RavenHawkTech',
                'manage_options',
                'ravenhawktech',
                [__CLASS__, 'render_ravenhawktech_page'],
                self::admin_menu_icon_url(),
                81
            );
        }

        add_submenu_page(
            'ravenhawktech',
            'RavenHawk Category Showcase',
            'Category Showcase',
            'manage_options',
            'rhcs-settings',
            [__CLASS__, 'render']
        );
    }

    private static function admin_menu_slug_exists(string $slug): bool {
        global $menu;

        if (!is_array($menu)) {
            return false;
        }

        foreach ($menu as $item) {
            if (isset($item[2]) && $item[2] === $slug) {
                return true;
            }
        }

        return false;
    }

    private static function admin_menu_icon_url(): string {
        return RHCS_PLUGIN_URL . 'assets/rht-admin-menu-icon.png';
    }

    private static function branding_icon_url(): string {
        return RHCS_PLUGIN_URL . 'assets/rht-admin-heading-icon.png';
    }

    public static function render_ravenhawktech_page(): void {
        if (!current_user_can('manage_options')) { return; } ?>
        <div class="wrap">
            <h1>
                <img src="<?php echo esc_url(self::branding_icon_url()); ?>" alt="" style="width: 20px; height: 20px; vertical-align: text-bottom; margin-right: 6px;">
                <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>
            </h1>
            <p>RavenHawkTech WordPress tools and connectors.</p>
            <p><a class="button button-primary" href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">Visit RavenHawkTech</a></p>
        </div>
    <?php }

    public static function settings(): void {
        register_setting('rhcs_settings', 'rhcs_auto_prepend_blog_page', [
            'type' => 'string',
            'sanitize_callback' => static fn($value) => $value === '1' ? '1' : '0',
            'default' => '1',
        ]);

        register_setting('rhcs_settings', 'rhcs_style_options', [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize_style_options'],
            'default' => RHCS_Category_Showcase::style_options(),
        ]);
    }

    public static function sanitize_style_options($value): array {
        $defaults = RHCS_Category_Showcase::style_options();
        $value = is_array($value) ? $value : [];
        $clean = [];

        foreach ($defaults as $key => $default) {
            if (in_array($key, ['border_radius', 'card_radius'], true)) {
                $clean[$key] = (string) max(0, min(60, absint($value[$key] ?? $default)));
                continue;
            }

            $color = sanitize_hex_color((string)($value[$key] ?? $default));
            $clean[$key] = $color ?: $default;
        }

        return $clean;
    }

    public static function render(): void {
        if (!current_user_can('manage_options')) { return; } ?>
        <div class="wrap">
            <h1>RavenHawk Category Showcase</h1>
            <p>Displays a styled WordPress category showcase with shortcode support and optional blog-page insertion. Visit <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>.</p>
            <form method="post" action="options.php">
                <?php settings_fields('rhcs_settings'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Auto-add to blog page</th>
                        <td>
                            <label>
                                <input type="checkbox" name="rhcs_auto_prepend_blog_page" value="1" <?php checked(get_option('rhcs_auto_prepend_blog_page', '1'), '1'); ?>>
                                Add the showcase automatically to the top of the assigned Posts page.
                            </label>
                        </td>
                    </tr>
                </table>

                <?php $style_options = RHCS_Category_Showcase::style_options(); ?>
                <h2>Showcase colors</h2>
                <p>Customize the category showcase colors without editing the plugin CSS file.</p>
                <table class="form-table" role="presentation">
                    <?php
                    $color_fields = [
                        'accent' => 'Accent color',
                        'accent_soft' => 'Soft accent color',
                        'background_start' => 'Background start',
                        'background_end' => 'Background end',
                        'card_start' => 'Card background start',
                        'card_end' => 'Card background end',
                        'text' => 'Main text',
                        'muted_text' => 'Description text',
                        'meta_text' => 'Meta text',
                    ];

                    foreach ($color_fields as $key => $label) : ?>
                        <tr>
                            <th scope="row"><?php echo esc_html($label); ?></th>
                            <td>
                                <input type="color" name="rhcs_style_options[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($style_options[$key]); ?>">
                                <code><?php echo esc_html($style_options[$key]); ?></code>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <th scope="row">Outer border radius</th>
                        <td>
                            <input type="number" min="0" max="60" name="rhcs_style_options[border_radius]" value="<?php echo esc_attr($style_options['border_radius']); ?>"> px
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Card border radius</th>
                        <td>
                            <input type="number" min="0" max="60" name="rhcs_style_options[card_radius]" value="<?php echo esc_attr($style_options['card_radius']); ?>"> px
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
            <h2>Shortcode</h2>
            <pre><code>[ravenhawk_category_showcase]</code></pre>
            <h2>Optional shortcode settings</h2>
            <pre><code>[ravenhawk_category_showcase limit="8" show_counts="true" show_descriptions="true"]</code></pre>
        </div>
    <?php }
}
RHCS_Admin::init();
